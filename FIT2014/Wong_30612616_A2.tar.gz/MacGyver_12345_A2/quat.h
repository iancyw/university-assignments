
typedef struct
{ 
  double  w;
  double  x;
  double  y;
  double  z;
}  Quaternion;

